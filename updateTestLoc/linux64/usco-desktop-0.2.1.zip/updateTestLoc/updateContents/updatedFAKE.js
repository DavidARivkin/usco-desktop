console.log("I am useless");
